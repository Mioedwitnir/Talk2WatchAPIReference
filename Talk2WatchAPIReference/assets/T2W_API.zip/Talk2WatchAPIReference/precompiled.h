// This file is used to store precompiled headers.

#include <QObject>
#include <QString>
#include <QVariant>
